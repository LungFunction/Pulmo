package com.example.lungfunction;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class DatabaseHelper extends SQLiteOpenHelper {

    // data base helper
    private static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Dbase";

    public static final String USER_TABLE_NAME = "User";
    public static final String USER_COLUMN_ID = "id";
    public static final String USER_COLUMN_NAME = "name";
    public static final String USER_COLUMN_AGE = "age";
    public static final String USER_COLUMN_GENDER = "gender";
    public static final String USER_COLUMN_BD = "BD";

    public static final String LC_TABLE_NAME = "Lung_capacity";
    public static final String LC_COLUMN_DATE = "Date";
    public static final String LC_COLUMN_VAL = "name";

    public static final String HR_TABLE_NAME = "Heart_rate";
    public static final String HR_COLUMN_DATE = "Date";
    public static final String HR_COLUMN_VAL = "name";

    public static final String OS_TABLE_NAME = "Oxygen_saturation";
    public static final String OS_COLUMN_DATE = "Date";
    public static final String OS_COLUMN_VAL = "name";

    public static final String FM_TABLE_NAME = "Freq_med";
    public static final String FM_COLUMN_DATE = "Date";
    public static final String FM_COLUMN_NUM = "name";
    public static final String FM_COLUMN_MED = "med_name";

    private Context context;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + USER_TABLE_NAME + " (" +
                USER_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USER_COLUMN_NAME + " TEXT, " +
                USER_COLUMN_BD + " TEXT, " +
                USER_COLUMN_AGE + " INT, " +
                USER_COLUMN_GENDER + " TEXT" + ")");
        sqLiteDatabase.execSQL("CREATE TABLE " + LC_TABLE_NAME + " (" +
                LC_COLUMN_DATE + " TEXT, " +
                LC_COLUMN_VAL + " DOUBLE " + ")");
        sqLiteDatabase.execSQL("CREATE TABLE " + HR_TABLE_NAME + " (" +
                HR_COLUMN_DATE + " TEXT, " +
                HR_COLUMN_VAL + " DOUBLE " + ")");
        sqLiteDatabase.execSQL("CREATE TABLE " + OS_TABLE_NAME + " (" +
                OS_COLUMN_DATE + " TEXT, " +
                OS_COLUMN_VAL + " DOUBLE " + ")");
        sqLiteDatabase.execSQL("CREATE TABLE " + FM_TABLE_NAME + " (" +
                FM_COLUMN_DATE + " TEXT, "+
                FM_COLUMN_NUM + " DOUBLE, " +  FM_COLUMN_MED + " TEXT" + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + USER_TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    //save user
    private void saveToUser(String name, int age, String gender, String Birthday, String id) {
        SQLiteDatabase database = new DatabaseHelper(context).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.USER_COLUMN_NAME, name);
        values.put(DatabaseHelper.USER_COLUMN_AGE, age);
        values.put(DatabaseHelper.USER_COLUMN_GENDER, gender);
        values.put(DatabaseHelper.USER_COLUMN_BD, Birthday);
        values.put(DatabaseHelper.USER_COLUMN_ID, id);
        long newRowId = database.insert(DatabaseHelper.USER_TABLE_NAME, null, values);

    }

    //save lung capacity
    public void saveToLC(String date, double val) {
        SQLiteDatabase database = new DatabaseHelper(context).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.LC_COLUMN_DATE, date);
        values.put(DatabaseHelper.LC_COLUMN_VAL, val);

        long newRowId = database.insert(DatabaseHelper.LC_TABLE_NAME, null, values);

    }

    //save heart rate
    private void saveToHR(String date, float val) {
        SQLiteDatabase database = new DatabaseHelper(context).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.HR_COLUMN_DATE, date);
        values.put(DatabaseHelper.HR_COLUMN_VAL, val);

        long newRowId = database.insert(DatabaseHelper.HR_TABLE_NAME, null, values);

    }


    //save oxygen saturation
    private void saveToOS(String date, float val) {
        SQLiteDatabase database = new DatabaseHelper(context).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.OS_COLUMN_DATE, date);
        values.put(DatabaseHelper.OS_COLUMN_VAL, val);

        long newRowId = database.insert(DatabaseHelper.LC_TABLE_NAME, null, values);

    }

    //save med use frequency
    private void addMedUse(String date, int val, String medicine) {
        SQLiteDatabase database = new DatabaseHelper(context).getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.FM_COLUMN_DATE, date);
        values.put(DatabaseHelper.FM_COLUMN_NUM,  val);
        values.put(DatabaseHelper.FM_COLUMN_MED, medicine);

        long newRowId = database.insert(DatabaseHelper.FM_TABLE_NAME, null, values);
    }


    class SQLiteOpenHelper
    {

    }

}