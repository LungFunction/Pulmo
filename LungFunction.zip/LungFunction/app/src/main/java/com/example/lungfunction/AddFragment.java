package com.example.lungfunction;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import java.util.Calendar;

import static com.example.lungfunction.MainActivity.insertEntry;
import static com.example.lungfunction.MainActivity.lungEntries;
import static com.example.lungfunction.MainActivity.monthKeys;
import static com.example.lungfunction.MainActivity.monthLung;
import static com.example.lungfunction.MainActivity.monthOxygen;
import static com.example.lungfunction.MainActivity.oxygenEntries;
import static com.example.lungfunction.MainActivity.writeData;

public class AddFragment extends Fragment {

    public static int selected;
    public static Button btnAdd;
    public static float value;
    EditText edtValue;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_add, container, false);

        //int tempEntries = oxygenEntries.getInt(monthKeys[1], 1) + 1;

        RadioGroup radioGroup = view.findViewById(R.id.radioGroup);
        RadioButton rBtnOxygen = view.findViewById(R.id.rBtnOxygen);
        RadioButton rBtnLung = view.findViewById(R.id.rBtnLung);

        btnAdd = view.findViewById(R.id.btnSubmit);
        //btnAdd.setVisibility(View.INVISIBLE);

        edtValue = view.findViewById(R.id.edtValue);
        //edtValue.setVisibility(View.INVISIBLE);

        selected = radioGroup.getCheckedRadioButtonId();


/*
        if (rBtnOxygen.isSelected()) {
            selected = 0;
            Log.d("Tag selected", "O");
            edtValue.setVisibility(View.VISIBLE);
        }

        if (rBtnLung.isSelected()) {
            selected = 1;
            Log.d("Tag selected", "L");
            edtValue.setVisibility(View.VISIBLE);
        }

        String text = edtValue.getText().toString();
        if (!text.isEmpty())
            btnAdd.setVisibility(View.VISIBLE);
*/

        // Inflate the layout for this fragment
        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        view.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value = Float.parseFloat(edtValue.getText().toString());
                writeData(selected, value);
/*                Log.d("Tag", String.valueOf(value));
                int month = Calendar.getInstance().get(Calendar.MONTH) - 1;
                SharedPreferences.Editor editor;

                if (selected == 0)
                {
                    editor = oxygenEntries.edit();
                    int tempEntries = oxygenEntries.getInt(monthKeys[month], 1) + 1;
                    editor.putInt(monthKeys[month], tempEntries);
                    editor.apply();

                    editor = monthOxygen.edit();
                    float tempTotal = monthOxygen.getFloat(monthKeys[month], 1) + value;
                    editor.putFloat(monthKeys[month], tempTotal);
                    editor.apply();
                }
                else
                {
                    editor = lungEntries.edit();
                    int tempEntries = lungEntries.getInt(monthKeys[month], 1) + 1;
                    editor.putInt(monthKeys[month], tempEntries);
                    editor.apply();

                    editor = monthLung.edit();
                    float tempTotal = monthLung.getFloat(monthKeys[month], 1) + value;
                    editor.putFloat(monthKeys[month], tempTotal);
                    editor.apply();
                }*/


                NavHostFragment.findNavController(AddFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });
    }
}