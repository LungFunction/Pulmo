package com.example.lungfunction;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.jjoe64.graphview.series.DataPoint;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.LiveData;
import androidx.room.Room;

import android.util.Log;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static int months = 4; //months that contain values
    public static double[] bloodOxygen = new double[12];//{50, 71, 65, 82, 95, 97, 23, 90, 45, 23, 76, 50};//new double[12];
    public static double[] lungCapacity = new double[12];//{3, 3.4, 4.6, 4.7, 4.7, 5, 5.3, 5.5, 5.65, 5.7, 5.76, 5.9};//new double[12];
    private static Repository mRepository;
    private static LiveData<List<Entry>> mAllEntries;

    //Going to record the data as key value pairs (the database shit is being really stubborn)
/*    private String janLung_key = "janLung";
    private String febLung_key = "febLung";
    private String marLung_key = "marLung";
    private String aprLung_key = "aprLung";
    private String mayLung_key = "marLung";
    private String junLung_key = "junLung";
    private String julLung_key = "julLung";
    private String augLung_key = "augLung";
    private String sepLung_key = "sepLung";
    private String octLung_key = "octLung";
    private String novLung_key = "novLung";
    private String decLung_key = "decLung";*/

    private static String[] lungKeys = {"janLung", "febLung", "marLung", "aprLung", "marLung", "junLung",
            "julLung", "augLung", "sepLung", "octLung", "novLung", "decLung"};

/*    private String janOxygen_key = "janOxygen";
    private String febOxygen_key = "febOxygen";
    private String marOxygen_key = "marOxygen";
    private String aprOxygen_key = "aprOxygen";
    private String mayOxygen_key = "marOxygen";
    private String junOxygen_key = "junOxygen";
    private String julOxygen_key = "julOxygen";
    private String augOxygen_key = "augOxygen";
    private String sepOxygen_key = "sepOxygen";
    private String octOxygen_key = "octOxygen";
    private String novOxygen_key = "novOxygen";
    private String decOxygen_key = "decOxygen";*/

    private static String[] oxygenKeys = {"janOxygen", "febOxygen", "marOxygen", "aprOxygen", "marOxygen",
            "junOxygen", "julOxygen", "augOxygen", "sepOxygen", "octOxygen", "novOxygen", "decOxygen"};

/*    private String janEntriesL_key = "janEntriesL";
    private String febEntriesL_key = "febEntriesL";
    private String MarEntriesL_key = "marEntriesL";
    private String aprEntriesL_key = "aprEntriesL";
    private String mayEntriesL_key = "marEntriesL";
    private String junEntriesL_key = "junEntriesL";
    private String julEntriesL_key = "julEntriesL";
    private String augEntriesL_key = "augEntriesL";
    private String sepEntriesL_key = "sepEntriesL";
    private String octEntriesL_key = "octEntriesL";
    private String novEntriesL_key = "novEntriesL";
    private String decEntriesL_key = "decEntriesL";*/



    private static String[] oxygenEntryKeys = { "janEntriesL", "febEntriesL", "marEntriesL", "aprEntriesL",
            "marEntriesL", "junEntriesL", "julEntriesL", "augEntriesL", "sepEntriesL", "octEntriesL",
            "novEntriesL", "decEntriesL"};

/*    private String janEntriesO_key = "janEntriesO";
    private String febEntriesO_key = "febEntriesO";
    private String marEntriesO_key = "marEntriesO";
    private String aprEntriesO_key = "aprEntriesO";
    private String mayEntriesO_key = "marEntriesO";
    private String junEntriesO_key = "junEntriesO";
    private String julEntriesO_key = "julEntriesO";
    private String augEntriesO_key = "augEntriesO";
    private String sepEntriesO_key = "sepEntriesO";
    private String octEntriesO_key = "octEntriesO";
    private String novEntriesO_key = "novEntriesO";
    private String decEntriesO_key = "decEntriesO";*/

    private static String[] lungEntryKeys = {"janEntriesO", "febEntriesO", "marEntriesO", "aprEntriesO",
            "marEntriesO", "junEntriesO", "julEntriesO", "augEntriesO", "sepEntriesO", "octEntriesO",
            "novEntriesO", "decEntriesO"};

    public static String[] monthKeys = {"Jan", "Feb", "Mar", "Apr", "Mar", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    private static int[] x = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

    public static SharedPreferences monthOxygen, monthLung, lungEntries, oxygenEntries;
    private static SharedPreferences testPref, sharedPref;
    private static Activity activity;
    private static SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Context context = this;
        activity = this;

/*        monthOxygen = context.getSharedPreferences(getString(R.string.oxygen_key), MODE_PRIVATE);
        monthLung = context.getSharedPreferences(getString(R.string.lung_key), MODE_PRIVATE);
        lungEntries = context.getSharedPreferences(getString(R.string.lungEntry_key), MODE_PRIVATE);
        oxygenEntries = context.getSharedPreferences(getString(R.string.oxygenEntry_key), MODE_PRIVATE);*/

/*        for (int i = 0; i < 12; i++)
        {
            monthOxygen = getSharedPreferences(oxygenKeys[i], MODE_PRIVATE);
            monthLung = getSharedPreferences(lungKeys[i], MODE_PRIVATE);
            lungEntries = getSharedPreferences(lungEntryKeys[i], MODE_PRIVATE);
            oxygenEntries = getSharedPreferences(oxygenEntryKeys[i], MODE_PRIVATE);
        }*/

        Application application = getApplication();

        sharedPref = this.getPreferences(Context.MODE_PRIVATE);
        mRepository = new Repository(application);

    }

    public static int[] testData()
    {
        testPref = activity.getPreferences(Context.MODE_PRIVATE);
        String[] testKeys = {"key1", "key2", "key3"};

        int[] returnVal = new int[3];
        int[] testVal;

        for (int i = 0; i < 3; i++)
        {
            editor = testPref.edit();
            editor.putInt(testKeys[i], i);
            editor.apply();

            returnVal[i] = testPref.getInt(testKeys[i], i);
        }

        return returnVal;
    }

    public static void readData()
    {
        float monthOxygen, monthLung;
        int entriesOxygen, entriesLung;

        for (int i = 0; i < 12; i++)
        {
            monthLung = sharedPref.getFloat(lungKeys[i], 0);
            monthOxygen = sharedPref.getFloat(oxygenKeys[i], 0);
            entriesLung = sharedPref.getInt(lungEntryKeys[i], 1);
            entriesOxygen = sharedPref.getInt(oxygenEntryKeys[i], 1);

            bloodOxygen[i] = monthOxygen/entriesOxygen;
            lungCapacity[i] = monthLung/entriesLung;
        }

/*        for (int i = 0; i < 12; i++)
        {
            bloodOxygen[i] = monthOxygen.getFloat(monthKeys[i], 0) / oxygenEntries.getInt(monthKeys[i], 1);
            *//*Log.d("Tag bloodOx", String.valueOf(monthOxygen.getFloat(monthKeys[i], 0)));*//*
            lungCapacity[i] = monthLung.getFloat(monthKeys[i], 0) / lungEntries.getInt(monthKeys[i], 1);
        }
        Log.d("Tag bloodOx", String.valueOf(monthOxygen.getFloat(monthKeys[10], 0)));*/
    }

    public static void writeData(int mode, float value) //mode = 0 -> blood oxygen
    {
        int month = 2;//Calendar.getInstance().get(Calendar.MONTH) - 1;
        editor = sharedPref.edit();

        int tempEntries;
        float tempVal;
        String entryKey, valKey;

        if (mode == 0)
        {
            entryKey = oxygenEntryKeys[month];
            valKey = oxygenKeys[month];
          // tempEntries = sharedPref.getInt(oxygenEntryKeys[month], 1);
           //tempVal = sharedPref.getFloat(oxygenKeys[month], 0);
        }
        else
        {
            entryKey = lungEntryKeys[month];
            valKey = lungKeys[month];
        }

         tempEntries = sharedPref.getInt(entryKey, 1);
        tempVal = sharedPref.getFloat(valKey, 0);

        editor.putInt(entryKey, tempEntries + 1);
        editor.putFloat(valKey, tempVal + value);
        editor.commit();

/*        int month = Calendar.getInstance().get(Calendar.MONTH) - 1;
        SharedPreferences.Editor editor;

        if (mode == 0)
        {
            editor = oxygenEntries.edit();
            int tempEntries = oxygenEntries.getInt(monthKeys[month], 1) + 1;
            editor.putInt(monthKeys[month], tempEntries);
            editor.commit();

            editor = monthOxygen.edit();
            float tempTotal = monthOxygen.getFloat(monthKeys[month], 1) + value;
            editor.putFloat(monthKeys[month], tempTotal);
            editor.commit();

            Log.d("Tag bloodOx", String.valueOf(monthOxygen.getFloat(monthKeys[month], 0)));
        }
        else
        {
            editor = lungEntries.edit();
            int tempEntries = lungEntries.getInt(monthKeys[month], 1) + 1;
            editor.putInt(monthKeys[month], tempEntries);
            editor.commit();

            editor = monthLung.edit();
            float tempTotal = monthLung.getFloat(monthKeys[month], 1) + value;
            editor.putFloat(monthKeys[month], tempTotal);
            editor.commit();
        }*/
    }

    public static LiveData<List<Entry>> getEntries()
    {
        mAllEntries = mRepository.getAllEntries();
        return mAllEntries;
    }

    public static void insertEntry(Entry entry)
    {
        mRepository.insert(entry);
    }

    public static DataPoint[] dataLung(){
        readData();
        int n=12;     //to find out the no. of data-points
        DataPoint[] values = new DataPoint[n];     //creating an object of type DataPoint[] of size 'n'
        for(int i=0;i<n;i++){
            DataPoint v = new DataPoint(x[i],lungCapacity[i]);
            values[i] = v;
        }
        return values;
    }

    public static DataPoint[] dataOxygen(){
        readData();
        int n=12;     //to find out the no. of data-points
        DataPoint[] values = new DataPoint[n];     //creating an object of type DataPoint[] of size 'n'
        for(int i=0;i<n;i++){
            DataPoint v = new DataPoint(x[i],bloodOxygen[i]);
            values[i] = v;
        }
        return values;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        return super.onOptionsItemSelected(item);
    }
}