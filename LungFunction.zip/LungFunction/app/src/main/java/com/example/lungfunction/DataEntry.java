package com.example.lungfunction;

public class DataEntry {
    public String date;
    public double value;
    public DataEntry(String date, double value)
    {
        this.date = date;
        this.value = value;
    }
}
