package com.example.lungfunction;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

public class DBManager {

    private DatabaseHelper dbHelper;

    private Context context;

    private SQLiteDatabase database;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context); //context
        database = dbHelper.getReadableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }



    public void insertOS(int val, String date) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.OS_COLUMN_DATE, date);
        contentValue.put(DatabaseHelper.OS_COLUMN_VAL, val);
        database.insert(DatabaseHelper.OS_TABLE_NAME, null, contentValue);
    }

    public void insertLC(int val, String date) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.LC_COLUMN_DATE, date);
        contentValue.put(DatabaseHelper.LC_COLUMN_VAL, val);
        database.insert(DatabaseHelper.LC_TABLE_NAME, null, contentValue);
    }

    public ArrayList<DataEntry> process(Cursor cursor, String col1, String col2)
    {
        cursor.moveToFirst();
        ArrayList<DataEntry> data = new ArrayList<DataEntry>();
        while(!cursor.isAfterLast()) {
            data.add(new DataEntry(cursor.getString(cursor.getColumnIndex(col1)),cursor.getDouble(cursor.getColumnIndex(col2)))); //cursor.getString(cursor.getColumnIndex("name"))
            cursor.moveToNext();
        }
        cursor.close();
        return data;
    }

    public ArrayList<DataEntry> fetchLC() {
        String[] columns = new String[] { DatabaseHelper.LC_COLUMN_DATE, DatabaseHelper.LC_COLUMN_VAL };

        // Filter results WHERE "val" != 0
        String selection = DatabaseHelper.LC_COLUMN_VAL + " != ?";
        String[] selectionArgs = { "0", "0" };

        // How you want the results sorted in the resulting Cursor
        String sortOrder = DatabaseHelper.LC_COLUMN_DATE+"DESC";

        Log.d("Tag name", DatabaseHelper.LC_TABLE_NAME);
        Log.d("Tag cols", columns[1]);
        Log.d("Tag selection", selection);
        Log.d("Tag selectionArgs", selectionArgs[1]);
        Log.d("Tag order", sortOrder);

        Cursor cursor = database.query(DatabaseHelper.LC_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        ArrayList<DataEntry> data = new ArrayList<DataEntry>();
        while(!cursor.isAfterLast()) {
            data.add(new DataEntry(cursor.getString(cursor.getColumnIndex(DatabaseHelper.LC_COLUMN_DATE)),cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.LC_COLUMN_VAL)))); //cursor.getString(cursor.getColumnIndex("name"))
            cursor.moveToNext();
        }
        cursor.close();
        return data;
    }

    public Cursor fetchOS() {
        String[] columns = new String[] { DatabaseHelper.OS_COLUMN_DATE, DatabaseHelper.OS_COLUMN_VAL };

        // Filter results WHERE "val" != 0
        String selection = DatabaseHelper.OS_COLUMN_VAL + " != ?";
        String[] selectionArgs = { "0" };

        // How you want the results sorted in the resulting Cursor
        String sortOrder = DatabaseHelper.LC_COLUMN_DATE+"DESC";

        Cursor cursor = database.query(DatabaseHelper.OS_TABLE_NAME, columns, selection, selectionArgs, null, null, sortOrder);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }


    public int updateLC(long _id, String name, String desc) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.LC_COLUMN_DATE, name);
        contentValues.put(DatabaseHelper.LC_COLUMN_VAL, desc);
        int i = database.update(DatabaseHelper.LC_TABLE_NAME, contentValues, null , null);
        return i;
    }

    public int updateOS(long _id, String name, String desc) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.OS_COLUMN_DATE, name);
        contentValues.put(DatabaseHelper.OS_COLUMN_VAL, desc);
        int i = database.update(DatabaseHelper.OS_TABLE_NAME, contentValues, null , null);
        return i;
    }

    public void deleteLC(long _id) {
        database.delete(DatabaseHelper.LC_TABLE_NAME, null, null);
    }

    public void deleteOS(long _id) {
        database.delete(DatabaseHelper.OS_TABLE_NAME, null, null);
    }

}