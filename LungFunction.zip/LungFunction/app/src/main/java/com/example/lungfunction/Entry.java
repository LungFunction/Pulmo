package com.example.lungfunction;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Entry {
    @PrimaryKey
    @NonNull
    public String date;
    //public int id;

/*    @ColumnInfo(name = "date")
    public String date;*/

    @ColumnInfo(name = "lung_capacity")
    public double lungCapacity;

    @ColumnInfo(name = "oxygen_saturation")
    public double oxygenSaturation;
}