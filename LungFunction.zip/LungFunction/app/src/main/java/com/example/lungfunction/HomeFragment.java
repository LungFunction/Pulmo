package com.example.lungfunction;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.PointsGraphSeries;

import static com.example.lungfunction.MainActivity.*;

public class HomeFragment extends Fragment {

    private static String[] lungKeys = {"janLung", "febLung", "marLung", "aprLung", "marLung", "junLung",
            "julLung", "augLung", "sepLung", "octLung", "novLung", "decLung"};

    private static String[] oxygenKeys = {"janOxygen", "febOxygen", "marOxygen", "aprOxygen", "marOxygen",
            "junOxygen", "julOxygen", "augOxygen", "sepOxygen", "octOxygen", "novOxygen", "decOxygen"};

    private static String[] oxygenEntryKeys = { "janEntriesL", "febEntriesL", "marEntriesL", "aprEntriesL",
            "marEntriesL", "junEntriesL", "julEntriesL", "augEntriesL", "sepEntriesL", "octEntriesL",
            "novEntriesL", "decEntriesL"};

    private static String[] lungEntryKeys = {"janEntriesO", "febEntriesO", "marEntriesO", "aprEntriesO",
            "marEntriesO", "junEntriesO", "julEntriesO", "augEntriesO", "sepEntriesO", "octEntriesO",
            "novEntriesO", "decEntriesO"};

    private static SharedPreferences monthOxygen, monthLung, lungEntries, oxygenEntries;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);


        final GraphView graphLung = (GraphView) view.findViewById(R.id.gViewLung);
        graphLung.setVisibility(View.VISIBLE);

        try {
            PointsGraphSeries<DataPoint> series= new PointsGraphSeries<>(dataLung());
            graphLung.addSeries(series);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), "Error, data not found", Toast.LENGTH_LONG).show();
        }

        final GraphView graphOxygen = (GraphView) view.findViewById(R.id.gViewOxygen);
        graphOxygen.setVisibility(View.VISIBLE);

        try {
            PointsGraphSeries<DataPoint> series= new PointsGraphSeries<>(dataOxygen());
            graphOxygen.addSeries(series);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), "Error, data not found", Toast.LENGTH_LONG).show();
        }

        // Inflate the layout for this fragment
        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.btnToAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(HomeFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });
    }
}