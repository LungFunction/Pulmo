package com.example.lungfunction;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface DataDao {
    @Query("SELECT * FROM entry")
    LiveData<List<Entry>> getAll();
   // List<Entry> getAll();

/*    @Query("SELECT * FROM entry WHERE id IN (:ids)")
    List<Entry> loadAllByIds(int[] ids);*/

    @Query("SELECT * FROM entry WHERE date LIKE :date LIMIT 1")
    Entry findByDate(String date);

    //@Query("SELECT date, lung_capacity FROM entry")


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(Entry... users);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Entry entry);

    @Delete
    void delete(Entry user);
}